"""Check static dictionary constant keys without evaluating scanned expressions."""

import ast
from collections.abc import Iterator

from sailtech_python_checks.declarations import (
    Kind,
    Violation,
    declaration,
    enum_declarations,
    import_bindings,
)


def check_dictionary_constants(module: ast.Module) -> list[Violation]:
    bindings = import_bindings(module)
    enums = {
        node.name
        for node, scope in enum_declarations(module).items()
        if scope is module
    }
    violations: list[Violation] = []
    for node in _module_assignments(module):
        symbol = _constant_symbol(node, bindings)
        value = node.value
        if symbol is None:
            continue
        if not isinstance(value, ast.Dict):
            continue
        names = _key_names(value, enums)
        if names is None or not all(_is_literal(entry) for entry in value.values):
            continue
        greatest = ""
        for key, name in zip(value.keys, names, strict=True):
            if key is not None and name < greatest:
                violations.append(
                    Violation(
                        key.lineno,
                        "PYORD010",
                        symbol,
                        "alphabetize static dictionary constant keys",
                    )
                )
            greatest = max(greatest, name)
    return violations


def _constant_symbol(
    node: ast.stmt,
    bindings: dict[str, str],
) -> str | None:
    item = declaration(node, bindings, in_class=False)
    if item is not None and item.kind is Kind.CONSTANT:
        return item.name
    if isinstance(node, ast.Assign):
        names = [
            target.id
            for target in node.targets
            if isinstance(target, ast.Name) and target.id.isupper()
        ]
        return ", ".join(names) if names else None
    return None


def _is_literal(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, (ast.Tuple, ast.List, ast.Set)):
        return all(_is_literal(element) for element in node.elts)
    if isinstance(node, ast.Dict):
        return all(key is not None and _is_literal(key) for key in node.keys) and all(
            _is_literal(value) for value in node.values
        )
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        return isinstance(node.operand, ast.Constant) and type(node.operand.value) in {
            int,
            float,
            complex,
        }
    return False


def _key_names(
    dictionary: ast.Dict,
    enums: set[str],
) -> list[str] | None:
    names: list[str] = []
    receiver: str | None = None
    for key in dictionary.keys:
        if isinstance(key, ast.Constant) and isinstance(key.value, str):
            kind, name = "string", key.value
        elif isinstance(key, ast.Attribute) and isinstance(key.value, ast.Name):
            if key.value.id not in enums:
                return None
            kind, name = "enum:" + key.value.id, key.attr
        else:
            return None
        if receiver is not None and receiver != kind:
            return None
        receiver = kind
        names.append(name)
    return names


def _module_assignments(node: ast.AST) -> Iterator[ast.Assign | ast.AnnAssign]:
    if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
        return
    if isinstance(node, (ast.Assign, ast.AnnAssign)):
        yield node
    for child in ast.iter_child_nodes(node):
        yield from _module_assignments(child)
