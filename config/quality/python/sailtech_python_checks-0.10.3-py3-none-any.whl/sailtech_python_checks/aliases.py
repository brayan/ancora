"""Check module alias groups using original definition-time dependencies."""

import ast
from itertools import pairwise

from sailtech_python_checks.declarations import (
    Declaration,
    Kind,
    Violation,
    declaration,
    lexical_imports,
)
from sailtech_python_checks.dependencies import definition_dependencies


def check_alias_suite(
    statements: list[ast.stmt],
    source: str,
    parents: dict[ast.AST, ast.AST],
) -> list[Violation]:
    groups = _alias_groups(statements, parents)
    if not groups:
        return []

    dependencies = definition_dependencies(
        statements,
        class_scope=False,
        preserve_external_reads=True,
    )
    positions = {node: index for index, node in enumerate(statements)}
    lines = source.splitlines()
    violations: list[Violation] = []
    for group in groups:
        indices = [positions[item.node] for item in group]
        required = {provider for index in indices for provider in dependencies[index]}
        target = indices[0]
        while target > 0:
            previous = target - 1
            is_definition = isinstance(
                statements[previous],
                (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
            )
            if not is_definition or previous in required:
                break
            target = previous
        if target < indices[0]:
            violations.append(
                Violation(
                    group[0].node.lineno,
                    "PYORD011",
                    group[0].name,
                    "place the alias group before unrelated definitions; preserve original dependencies and bindings",
                )
            )
        violations.extend(_check_spacing(group, lines))
    return violations


def _alias_groups(
    statements: list[ast.stmt],
    parents: dict[ast.AST, ast.AST],
) -> list[list[Declaration]]:
    groups: list[list[Declaration]] = []
    current: list[Declaration] = []
    for node in statements:
        is_candidate = (
            isinstance(node, (ast.Assign, ast.AnnAssign))
            or type(node).__name__ == "TypeAlias"
        )
        item = (
            declaration(node, lexical_imports(node, parents), in_class=False)
            if is_candidate
            else None
        )
        if item is not None and item.kind == Kind.ALIAS:
            current.append(item)
        elif current:
            groups.append(current)
            current = []
    if current:
        groups.append(current)
    return groups


def _check_spacing(
    group: list[Declaration],
    lines: list[str],
) -> list[Violation]:
    violations: list[Violation] = []
    for previous, current in pairwise(group):
        end = previous.node.end_lineno
        if end is None:
            raise ValueError("missing alias source location")
        gap = lines[end : current.node.lineno - 1]
        section = any(line.lstrip().startswith("#") for line in gap)
        repeated = any(
            not left.strip() and not right.strip() for left, right in pairwise(gap)
        )
        has_unsectioned_gap = not section and any(not line.strip() for line in gap)
        if repeated or has_unsectioned_gap:
            violations.append(
                Violation(
                    current.node.lineno,
                    "PYORD012",
                    current.name,
                    "keep consecutive module aliases together; only a section comment permits a single blank separator",
                )
            )
    return violations
