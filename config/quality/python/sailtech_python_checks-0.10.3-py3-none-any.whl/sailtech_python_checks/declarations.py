"""Classify declaration syntax and check data sections without importing source."""

import ast
from dataclasses import dataclass
from enum import IntEnum
from itertools import pairwise

from sailtech_python_checks.dependencies import (
    bound_names,
    canonical_order,
    deleted_names,
)


def import_bindings(module: ast.Module) -> dict[str, str]:
    bindings: dict[str, str] = {}
    for node in module.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bindings[alias.asname or alias.name.split(".")[0]] = (
                    alias.name if alias.asname else alias.name.split(".")[0]
                )
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                bindings[alias.asname or alias.name] = node.module + "." + alias.name
    # Rebound imports are ambiguous; do not infer their typing role.
    for node in module.body:
        if isinstance(node, ast.AnnAssign) and node.value is None:
            continue
        name = (
            node.name
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
            else _target_name(node)
        )
        if name is not None:
            bindings.pop(name, None)
    return bindings


class Kind(IntEnum):
    ALIAS = 2
    CLASS_VARIABLE = 3
    CONFIGURATION = 0
    CONSTANT = 1
    FIELD = 4
    VARIABLE = 5


@dataclass(frozen=True)
class Declaration:
    kind: Kind
    name: str
    node: ast.stmt


def declaration(
    node: ast.stmt,
    bindings: dict[str, str],
    *,
    in_class: bool,
) -> Declaration | None:
    name = _target_name(node)
    if name is None:
        return None
    annotation = node.annotation if isinstance(node, ast.AnnAssign) else None
    annotation_name = qualified_name(_annotation_root(annotation), bindings)
    if annotation_name == "dataclasses.KW_ONLY":
        return None
    value = node.value if isinstance(node, (ast.Assign, ast.AnnAssign)) else None
    is_constant = name.isupper() or annotation_name in {
        "typing.Final",
        "typing_extensions.Final",
    }
    if in_class and name in {"model_config", "__slots__", "__match_args__"}:
        kind = Kind.CONFIGURATION
    elif _is_alias(node, annotation_name, value, bindings):
        kind = Kind.ALIAS
    elif is_constant:
        kind = Kind.CONSTANT
    elif annotation_name in {"typing.ClassVar", "typing_extensions.ClassVar"}:
        kind = Kind.CLASS_VARIABLE
    elif in_class and isinstance(node, ast.AnnAssign):
        kind = Kind.FIELD
    else:
        kind = Kind.CLASS_VARIABLE if in_class else Kind.VARIABLE
    return Declaration(kind, name, node)


def qualified_name(
    expression: ast.expr | None,
    bindings: dict[str, str],
) -> str:
    if isinstance(expression, ast.Name):
        return bindings.get(expression.id, expression.id)
    if isinstance(expression, ast.Attribute):
        return qualified_name(expression.value, bindings) + "." + expression.attr
    return ""


@dataclass(frozen=True)
class Violation:
    line: int
    rule: str
    symbol: str
    message: str
    scope_line: int | None = None


def check_declarations(
    module: ast.Module,
    source: str,
) -> list[Violation]:
    bindings = import_bindings(module)
    parents = {
        child: parent
        for parent in ast.walk(module)
        for child in ast.iter_child_nodes(parent)
    }
    lines = source.split("\n")
    violations: list[Violation] = []
    enums = enum_declarations(module)
    for scope in ast.walk(module):
        if not isinstance(scope, (ast.Module, ast.ClassDef)):
            continue
        in_class = isinstance(scope, ast.ClassDef)
        if isinstance(scope, ast.ClassDef) and scope in enums:
            violations.extend(_check_enum(scope))
            continue
        positional = (
            _positional_fields(scope, parents)
            if isinstance(scope, ast.ClassDef)
            else ()
        )
        for block in _data_blocks(
            scope.body, bindings, in_class=in_class, parents=parents
        ):
            violations.extend(_check_block(block, lines, scope, positional))
    return violations


def enum_declarations(module: ast.Module) -> dict[ast.ClassDef, ast.AST]:
    known = {
        "enum.Enum",
        "enum.IntEnum",
        "enum.StrEnum",
        "enum.Flag",
        "enum.IntFlag",
        "enum.ReprEnum",
    }
    declarations: dict[ast.ClassDef, ast.AST] = {}
    parents = {
        child: parent
        for parent in ast.walk(module)
        for child in ast.iter_child_nodes(parent)
    }
    classes = [node for node in ast.walk(module) if isinstance(node, ast.ClassDef)]
    while True:
        previous_count = len(declarations)
        for node in classes:
            scope = _containing_scope(node, parents)
            for base in node.bases:
                provider = _definition_provider(base, node, parents)
                is_builtin = isinstance(provider, str) and provider in known
                is_local_enum = (
                    isinstance(provider, ast.ClassDef) and provider in declarations
                )
                if is_builtin or is_local_enum:
                    declarations[node] = scope
        if len(declarations) == previous_count:
            return declarations


def lexical_imports(
    statement: ast.stmt,
    parents: dict[ast.AST, ast.AST],
) -> dict[str, str]:
    bindings: dict[str, str] = {}
    for node in ast.walk(statement):
        if isinstance(node, ast.Name):
            provider = _definition_provider(node, statement, parents)
            if isinstance(provider, str):
                bindings[node.id] = provider
    return bindings


def _containing_scope(
    node: ast.AST,
    parents: dict[ast.AST, ast.AST],
) -> ast.AST:
    parent = parents[node]
    while not isinstance(
        parent, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
    ):
        parent = parents[parent]
    return parent


def _definition_provider(
    expression: ast.expr | None,
    consumer: ast.stmt,
    parents: dict[ast.AST, ast.AST],
) -> str | ast.ClassDef | None:
    if isinstance(expression, ast.Attribute):
        provider = _definition_provider(expression.value, consumer, parents)
        return provider + "." + expression.attr if isinstance(provider, str) else None
    if not isinstance(expression, ast.Name):
        return None
    scope = _containing_scope(consumer, parents)
    deferred = False
    immediate = True
    while True:
        if immediate or not isinstance(scope, ast.ClassDef):
            statements = _scope_statements(scope)
            candidates = [
                statement
                for statement in statements
                if (deferred or statement.lineno < consumer.lineno)
                and expression.id in bound_names(statement) | deleted_names(statement)
            ]
            if candidates:
                provider = candidates[-1]
                if expression.id not in deleted_names(provider):
                    if isinstance(provider, ast.ClassDef):
                        return provider
                    return import_bindings(
                        ast.Module(body=[provider], type_ignores=[])
                    ).get(expression.id)
            if isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef)):
                local_names = {
                    argument.arg
                    for argument in ast.walk(scope.args)
                    if isinstance(argument, ast.arg)
                }
                local_names.update(
                    name
                    for statement in statements
                    for name in bound_names(statement) | deleted_names(statement)
                )
                local_names.update(
                    statement.target.id
                    for statement in statements
                    if isinstance(statement, ast.AnnAssign)
                    and isinstance(statement.target, ast.Name)
                )
                if expression.id in local_names:
                    return None
                deferred = True
        if isinstance(scope, ast.Module):
            return None
        scope = _containing_scope(scope, parents)
        immediate = False


def _scope_statements(node: ast.AST) -> list[ast.stmt]:
    statements: list[ast.stmt] = []
    for child in ast.iter_child_nodes(node):
        if isinstance(child, ast.stmt):
            statements.append(child)
        if not isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            statements.extend(_scope_statements(child))
    return statements


def _target_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Assign) and len(node.targets) == 1:
        target = node.targets[0]
    elif isinstance(node, ast.AnnAssign):
        target = node.target
    elif type(node).__name__ == "TypeAlias":
        target = next(value for key, value in ast.iter_fields(node) if key == "name")
    else:
        return None
    return target.id if isinstance(target, ast.Name) else None


def _annotation_root(annotation: ast.expr | None) -> ast.expr | None:
    return annotation.value if isinstance(annotation, ast.Subscript) else annotation


def _is_alias(
    node: ast.stmt,
    annotation_name: str,
    value: ast.expr | None,
    bindings: dict[str, str],
) -> bool:
    if type(node).__name__ == "TypeAlias":
        return True
    if annotation_name in {"typing.TypeAlias", "typing_extensions.TypeAlias"}:
        return True
    if not isinstance(value, ast.Subscript):
        return False
    name = qualified_name(value.value, bindings)
    return name in {
        "typing.Annotated",
        "typing.Literal",
        "typing.Union",
        "typing.Optional",
        "typing_extensions.Annotated",
        "typing_extensions.Literal",
        "list",
        "dict",
        "tuple",
        "set",
        "frozenset",
        "type",
    }


def _check_enum(scope: ast.ClassDef) -> list[Violation]:
    greatest = ""
    violations: list[Violation] = []
    for statement in scope.body:
        if isinstance(statement, ast.Assign):
            targets = statement.targets
        elif isinstance(statement, ast.AnnAssign) and statement.value is not None:
            targets = [statement.target]
        else:
            targets = []
        for target in targets:
            if not isinstance(target, ast.Name):
                raise TypeError("enum members must have explicit identifier targets")
            name = target.id
            if name.startswith("_") and name.endswith("_"):
                continue
            if name < greatest:
                violations.append(
                    Violation(
                        statement.lineno,
                        "PYORD009",
                        name,
                        "alphabetize enum member names",
                    )
                )
            greatest = max(greatest, name)
    return violations


def _positional_fields(
    scope: ast.ClassDef,
    parents: dict[ast.AST, ast.AST],
) -> tuple[str, ...]:
    decorators = [
        node
        for node in scope.decorator_list
        if _definition_provider(
            node.func if isinstance(node, ast.Call) else node, scope, parents
        )
        == "dataclasses.dataclass"
    ]
    if not decorators:
        return ()
    decorator = decorators[0]
    if not _literal_option(decorator, "init", default=True):
        return ()
    keyword_only = _literal_option(decorator, "kw_only", default=False)
    names: list[str] = []
    for statement in scope.body:
        if not isinstance(statement, ast.AnnAssign) or not statement.simple:
            continue
        if not isinstance(statement.target, ast.Name):
            continue
        annotation = statement.annotation
        if isinstance(annotation, ast.Constant) and isinstance(annotation.value, str):
            annotation = ast.parse(annotation.value, mode="eval").body
        annotation_name = _definition_provider(
            _annotation_root(annotation), statement, parents
        )
        is_keyword_sentinel = annotation_name == "dataclasses.KW_ONLY"
        if is_keyword_sentinel:
            keyword_only = True
            continue
        if annotation_name in {"typing.ClassVar", "typing_extensions.ClassVar"}:
            continue
        value = statement.value
        is_field = (
            isinstance(value, ast.Call)
            and _definition_provider(value.func, statement, parents)
            == "dataclasses.field"
        )
        positional = not (
            _literal_option(value, "kw_only", default=keyword_only)
            if is_field
            else keyword_only
        )
        initialized = _literal_option(value, "init", default=True) if is_field else True
        if positional and initialized:
            names.append(statement.target.id)
    return tuple(names)


def _literal_option(
    node: ast.AST | None,
    name: str,
    *,
    default: bool,
) -> bool:
    if not isinstance(node, ast.Call):
        return default
    for keyword in node.keywords:
        if keyword.arg is None:
            raise ValueError(
                "dynamic dataclass options cannot define a static constructor contract"
            )
        if keyword.arg != name:
            continue
        if isinstance(keyword.value, ast.Constant):
            value = keyword.value.value
            if isinstance(value, bool):
                return value
        raise ValueError("dataclass constructor options must be literal booleans")
    return default


def _data_blocks(
    statements: list[ast.stmt],
    bindings: dict[str, str],
    *,
    in_class: bool,
    parents: dict[ast.AST, ast.AST],
) -> list[list[Declaration]]:
    blocks: list[list[Declaration]] = []
    current: list[Declaration] = []
    for statement in statements:
        scoped_bindings = lexical_imports(statement, parents) if in_class else bindings
        item = declaration(statement, scoped_bindings, in_class=in_class)
        if item is not None:
            current.append(item)
        elif current:
            blocks.append(current)
            current = []
    if current:
        blocks.append(current)
    return blocks


def _check_block(
    block: list[Declaration],
    lines: list[str],
    scope: ast.Module | ast.ClassDef,
    positional_names: tuple[str, ...],
) -> list[Violation]:
    violations: list[Violation] = []
    scope_line = scope.lineno if isinstance(scope, ast.ClassDef) else None
    rule = "PYORD004" if scope_line is not None else "PYORD003"
    statements = [item.node for item in block]
    keys = {index: (int(item.kind), item.name) for index, item in enumerate(block)}
    expected = canonical_order(
        statements,
        keys,
        class_scope=isinstance(scope, ast.ClassDef),
        positional_names=positional_names,
    )
    ranks = {index: rank for rank, index in enumerate(expected)}
    greatest = -1
    for index, item in enumerate(block):
        rank = ranks[index]
        if rank < greatest:
            violations.append(
                Violation(
                    item.node.lineno,
                    rule,
                    item.name,
                    "group independent declarations by kind, then alphabetize names",
                    scope_line,
                )
            )
        greatest = max(greatest, rank)
    for previous, current in pairwise(block):
        if previous.kind == current.kind:
            continue
        end = previous.node.end_lineno
        if end is None:
            raise ValueError("declaration source location missing")
        blanks = sum(not line.strip() for line in lines[end : current.node.lineno - 1])
        allows_compact_config = (
            scope_line is not None
            and previous.kind == Kind.CONFIGURATION
            and previous.name == "model_config"
            and previous.node.lineno == end
            and current.kind == Kind.FIELD
        )
        has_valid_gap = blanks == 1 or (allows_compact_config and blanks == 0)
        if not has_valid_gap:
            violations.append(
                Violation(
                    current.node.lineno,
                    "PYORD005",
                    current.name,
                    "use exactly one blank line between declaration kinds",
                    scope_line,
                )
            )
    return violations
