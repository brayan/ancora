import argparse
import os
import re
import subprocess
import sys
import tempfile
from collections.abc import Sequence
from pathlib import Path

from sailtech_python_checks import __version__


def snapshot_sources(
    source_root: Path,
    snapshot_root: Path,
) -> list[Path]:
    domains: set[Path] = set()
    for source in sorted(source_root.rglob("*")):
        if source.is_symlink():
            raise ValueError("source trees containing symlinks are unsupported")
        if not source.is_file() or source.suffix != ".py":
            continue
        relative = source.relative_to(source_root)
        target = snapshot_root / "src" / relative
        target.parent.mkdir(exist_ok=True, parents=True)
        target.write_bytes(source.read_bytes())
        if "domain" in relative.parts[:-1]:
            domain_index = relative.parts.index("domain")
            domains.add(Path("src", *relative.parts[: domain_index + 1]))
    return sorted(domains)


def report_external_imports(
    snapshot_root: Path,
    domain: Path,
) -> list[str]:
    command = [
        sys.executable,
        "-B",
        "-m",
        "tach",
        "report",
        "--external",
        "--raw",
        str(domain),
    ]
    result = subprocess.run(
        command,
        capture_output=True,
        check=False,
        cwd=snapshot_root,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise ValueError(
            "Tach could not analyze domain imports; install the architecture extra and check source syntax"
        )
    lines = result.stdout.strip().splitlines()
    if not lines:
        return []
    valid_report = lines[0] == "# External Dependencies" and len(lines) > 1
    valid_packages = all(
        re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", line) for line in lines[1:]
    )
    if not valid_report or not valid_packages:
        raise ValueError("unsupported Tach external-report output")
    return lines[1:]


def check_domains(source_root: Path) -> list[str]:
    if source_root.is_symlink() or not source_root.is_dir():
        raise ValueError("--source-root must be an existing directory without symlinks")
    with tempfile.TemporaryDirectory(prefix="sailtech-domain-check-") as temporary:
        snapshot_root = Path(temporary)
        domains = snapshot_sources(source_root.resolve(), snapshot_root)
        config = 'source_roots = ["src"]\nignore_type_checking_imports = false\nrespect_gitignore = false\nexclude = []\n'
        (snapshot_root / "tach.toml").write_text(config, encoding="utf-8")
        violations: list[str] = []
        for domain in domains:
            packages = report_external_imports(snapshot_root, domain)
            original = source_root / domain.relative_to("src")
            violations.extend(
                f"{original}: domain imports third-party package {package}"
                for package in packages
            )
        return violations


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Reject third-party domain imports using Tach's static analysis. Never executes scanned code."
    )
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--source-root", required=True, type=Path)
    arguments = parser.parse_args(argv)
    try:
        violations = check_domains(arguments.source_root)
    except (OSError, ValueError, subprocess.TimeoutExpired):
        print(
            "Cannot check domain imports: verify the source root, source syntax and installed Tach architecture extra.",
            file=sys.stderr,
        )
        return 2
    for violation in violations:
        print(violation, file=sys.stderr)
    return 1 if violations else 0


if __name__ == "__main__":
    raise SystemExit(main())
