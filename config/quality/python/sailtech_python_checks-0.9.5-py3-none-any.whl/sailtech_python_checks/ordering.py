"""Check declarations, dictionaries, tests and keywords without executing source."""

import argparse
import ast
import io
import re
import sys
import tokenize
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from sailtech_python_checks import __version__
from sailtech_python_checks.declarations import Violation, check_declarations
from sailtech_python_checks.dependencies import canonical_order
from sailtech_python_checks.dictionaries import check_dictionary_constants
from sailtech_python_checks.parameters import python_files

FORBIDDEN_SUPPRESSION = re.compile(
    r"^#\s*(?:fmt\s*:\s*(?:off|skip)|sailtech[-_]order\s*:|(?:ruff|flake8)\s*:\s*noqa\b|noqa\b|type\s*:\s*ignore\b|pyright\s*:|pylint\s*:\s*disable|isort\s*:\s*(?:skip|off)|pragma\s*:\s*no\s*(?:cover|branch))",
    re.IGNORECASE,
)


def check_source(
    source: str,
    *,
    filename: str = "<source>",
) -> list[Violation]:
    module = ast.parse(source)
    functions = [
        node
        for node in ast.walk(module)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    parents = {
        child: parent
        for parent in ast.walk(module)
        for child in ast.iter_child_nodes(parent)
    }
    violations = check_declarations(module, source)
    violations.extend(check_dictionary_constants(module))
    is_test_module = Path(filename).name.startswith("test_") or Path(
        filename
    ).stem.endswith("_test")
    for node in ast.walk(module):
        scope = _visibility_scope(node, parents)
        if scope is not None:
            for suite in _declaration_suites(node):
                class_scope = isinstance(scope, ast.ClassDef)
                violations.extend(
                    _check_order(suite, "classes", class_scope=class_scope)
                )
                violations.extend(
                    _check_order(suite, "visibility", class_scope=class_scope)
                )
                if is_test_module:
                    violations.extend(
                        _check_order(suite, "tests", class_scope=class_scope)
                    )
    for function in functions:
        names = [parameter.arg for parameter in function.args.kwonlyargs]
        if names != sorted(names):
            violations.append(
                Violation(
                    function.lineno,
                    "PYORD002",
                    function.name,
                    "alphabetize declared keyword-only parameters; preserve positional parameters",
                )
            )

    violations.extend(_check_calls(module))
    violations.extend(_check_suppressions(source))
    return sorted(violations, key=lambda item: (item.line, item.rule))


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Check class/declaration order, visibility, tests and keyword order. Check-only; never executes scanned code."
    )
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("paths", nargs="+", type=Path)
    arguments = parser.parse_args(argv)
    try:
        files = python_files(arguments.paths)
    except (OSError, ValueError) as error:
        parser.error(str(error))

    status = 0
    for path in files:
        try:
            with tokenize.open(path) as stream:
                violations = check_source(stream.read(), filename=str(path))
        except (
            OSError,
            UnicodeError,
            SyntaxError,
            TypeError,
            ValueError,
            StopIteration,
            tokenize.TokenError,
        ) as error:
            print(
                f"{path}: cannot check Python source ({type(error).__name__})",
                file=sys.stderr,
            )
            status = 2
            continue
        for violation in violations:
            print(
                f"{path}:{violation.line}: {violation.rule}: {violation.symbol}: {violation.message}"
            )
            status = max(status, 1)
    return status


def _visibility_scope(
    node: ast.AST,
    parents: dict[ast.AST, ast.AST],
) -> ast.Module | ast.ClassDef | None:
    while not isinstance(node, (ast.Module, ast.ClassDef)):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            return None
        parent = parents.get(node)
        if parent is None:
            return None
        node = parent
    return node


def _declaration_suites(node: ast.AST) -> list[list[ast.stmt]]:
    suites: list[list[ast.stmt]] = []
    # Field traversal also covers except* on interpreters newer than Python 3.10.
    for field, value in ast.iter_fields(node):
        if field not in {"body", "orelse", "finalbody"} or not isinstance(value, list):
            continue
        statements = [
            item for item in cast(list[object], value) if isinstance(item, ast.stmt)
        ]
        suites.append(statements)
    return suites


def _check_order(
    statements: list[ast.stmt],
    kind: str,
    *,
    class_scope: bool,
) -> list[Violation]:
    keys: dict[int, tuple[int, str]] = {}
    rules = {"classes": "PYORD008", "visibility": "PYORD001", "tests": "PYORD006"}
    for index, node in enumerate(statements):
        if kind == "classes" and isinstance(node, ast.ClassDef):
            keys[index] = (0, node.name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if kind == "tests" and node.name.startswith("test_"):
                keys[index] = (0, node.name)
            elif kind == "visibility":
                is_protocol_hook = node.name.startswith("__") and node.name.endswith(
                    "__"
                )
                if not is_protocol_hook:
                    keys[index] = (int(node.name.startswith("_")), f"{index:012d}")
    if not keys:
        return []
    expected = [
        index
        for index in canonical_order(statements, keys, class_scope=class_scope)
        if index in keys
    ]
    ranks = {index: rank for rank, index in enumerate(expected)}
    greatest = -1
    violations: list[Violation] = []
    for index in keys:
        rank = ranks[index]
        if rank < greatest:
            violations.append(
                Violation(
                    statements[index].lineno,
                    rules[kind],
                    getattr(statements[index], "name", kind),
                    "use dependency-aware "
                    + kind
                    + " order; alphabetize independent declarations",
                )
            )
        greatest = max(greatest, rank)
    return violations


def _check_calls(module: ast.Module) -> list[Violation]:
    violations: list[Violation] = []
    for node in ast.walk(module):
        if not isinstance(node, ast.Call):
            continue
        group: list[str] = []
        invalid = False
        for keyword in node.keywords:
            if keyword.arg is None:
                invalid = invalid or group != sorted(group)
                group = []
            else:
                group.append(keyword.arg)
        if invalid or group != sorted(group):
            violations.append(
                Violation(
                    node.lineno,
                    "PYORD007",
                    "call",
                    "alphabetize explicit keyword arguments within unpacking boundaries; preserve evaluation semantics",
                )
            )
    return violations


def _check_suppressions(source: str) -> list[Violation]:
    return [
        Violation(
            token.start[0],
            "PYORD000",
            "suppression",
            "suppression comments are forbidden",
        )
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type == tokenize.COMMENT
        and any(
            FORBIDDEN_SUPPRESSION.match("#" + part)
            for part in token.string.split("#")[1:]
        )
    ]


if __name__ == "__main__":
    raise SystemExit(main())
