"""Derive definition-time constraints and deterministic ordering from Python ASTs."""

import ast
import builtins
from collections.abc import Iterable
from itertools import pairwise


def bound_names(node: ast.stmt) -> set[str]:
    expression_bindings = _named_expression_bindings(node)
    if isinstance(node, ast.AnnAssign) and node.value is None:
        return expression_bindings
    if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
        return {node.name} | expression_bindings
    if isinstance(node, ast.Import):
        return {alias.asname or alias.name.split(".")[0] for alias in node.names}
    if isinstance(node, ast.ImportFrom):
        return {alias.asname or alias.name for alias in node.names}
    if isinstance(node, ast.Assign):
        targets = node.targets
    elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
        targets = [node.target]
    else:
        targets = [value for key, value in ast.iter_fields(node) if key == "name"]
    return expression_bindings | {
        item.id
        for target in targets
        if isinstance(target, ast.AST)
        for item in ast.walk(target)
        if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store)
    }


def canonical_order(
    statements: list[ast.stmt],
    keys: dict[int, tuple[int, str]],
    *,
    class_scope: bool = False,
    positional_names: tuple[str, ...] = (),
) -> list[int]:
    dependencies = _dependencies(statements, class_scope=class_scope)
    for index, statement in enumerate(statements):
        is_binding = (
            isinstance(
                statement,
                (
                    ast.Import,
                    ast.ImportFrom,
                    ast.ClassDef,
                    ast.FunctionDef,
                    ast.AsyncFunctionDef,
                    ast.Assign,
                    ast.AnnAssign,
                    ast.AugAssign,
                ),
            )
            or type(statement).__name__ == "TypeAlias"
        )
        if index not in keys and not is_binding and not isinstance(statement, ast.Pass):
            dependencies[index].update(range(index))
            for later in range(index + 1, len(statements)):
                dependencies[later].add(index)
    anchors = [index for index in range(len(statements)) if index not in keys]
    for earlier, later in pairwise(anchors):
        dependencies[later].add(earlier)
    positions = {name: index for index, (_, name) in keys.items()}
    positional = [positions[name] for name in positional_names if name in positions]
    for earlier, later in pairwise(positional):
        dependencies[later].add(earlier)

    ordered: list[int] = []
    remaining = set(dependencies)
    while remaining:
        ready = [index for index in remaining if not dependencies[index] & remaining]
        if not ready:
            raise ValueError("cyclic definition-time ordering constraints")
        selected = min(
            ready,
            key=lambda index: (
                (1, *keys[index], index) if index in keys else (0, 0, "", index)
            ),
        )
        ordered.append(selected)
        remaining.remove(selected)
    return ordered


def deleted_names(node: ast.stmt) -> set[str]:
    if not isinstance(node, ast.Delete):
        return set()
    return {
        target.id
        for target in ast.walk(node)
        if isinstance(target, ast.Name) and isinstance(target.ctx, ast.Del)
    }


def evaluated_names(node: ast.AST) -> set[str]:
    return _evaluated_names(node, class_scope=False, local_names=frozenset())


def _comprehension_names(
    node: ast.ListComp | ast.SetComp | ast.DictComp,
    *,
    class_scope: bool,
    local_names: frozenset[str],
) -> set[str]:
    names = _evaluated_names(
        node.generators[0].iter, class_scope=class_scope, local_names=local_names
    )
    bound: set[str] = set() if class_scope else set(local_names)
    for index, generator in enumerate(node.generators):
        if index:
            names.update(
                _evaluated_names(
                    generator.iter, class_scope=False, local_names=frozenset(bound)
                )
            )
        bound.update(
            item.id
            for item in ast.walk(generator.target)
            if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store)
        )
        names.update(_references(generator.ifs, local_names=frozenset(bound)))
    elements = [node.key, node.value] if isinstance(node, ast.DictComp) else [node.elt]
    names.update(_references(elements, local_names=frozenset(bound)))
    return names


def _dependencies(
    statements: list[ast.stmt],
    *,
    class_scope: bool,
) -> dict[int, set[int]]:
    providers: dict[str, list[int]] = {}
    for index, statement in enumerate(statements):
        for name in bound_names(statement):
            providers.setdefault(name, []).append(index)
    dependencies: dict[int, set[int]] = {
        index: set() for index in range(len(statements))
    }
    for positions in providers.values():
        for earlier, later in pairwise(positions):
            dependencies[later].add(earlier)
    for index, statement in enumerate(statements):
        for name in evaluated_names(statement):
            positions = [
                position for position in providers.get(name, []) if position != index
            ]
            earlier = [position for position in positions if position < index]
            later = [position for position in positions if position > index]
            if earlier:
                dependencies[index].add(earlier[-1])
                if later:
                    dependencies[later[0]].add(index)
            elif later:
                if class_scope or name in vars(builtins):
                    dependencies[later[0]].add(index)
                else:
                    dependencies[index].add(later[0])
    return dependencies


def _evaluated_names(
    node: ast.AST,
    *,
    class_scope: bool,
    local_names: frozenset[str],
) -> set[str]:
    if isinstance(node, ast.Name):
        return (
            {node.id}
            if isinstance(node.ctx, ast.Load) and node.id not in local_names
            else set()
        )
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        expressions: Iterable[ast.AST] = (
            list(node.decorator_list)
            + [node.args]
            + ([node.returns] if node.returns is not None else [])
        )
        return _references(
            expressions, class_scope=class_scope, local_names=local_names
        ) - _type_parameters(node)
    if isinstance(node, ast.ClassDef):
        names = _references(
            [*node.bases, *node.keywords, *node.decorator_list],
            class_scope=class_scope,
            local_names=local_names,
        )
        local = _type_parameters(node)
        for statement in node.body:
            names.update(
                _evaluated_names(
                    statement, class_scope=True, local_names=frozenset(local)
                )
            )
            local.update(bound_names(statement))
            local.difference_update(deleted_names(statement))
        return names
    if isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp)):
        return _comprehension_names(
            node, class_scope=class_scope, local_names=local_names
        )
    if isinstance(node, ast.GeneratorExp):
        return _evaluated_names(
            node.generators[0].iter, class_scope=class_scope, local_names=local_names
        )
    if isinstance(node, ast.Lambda):
        return _evaluated_names(
            node.args, class_scope=class_scope, local_names=local_names
        )
    return _references(
        ast.iter_child_nodes(node), class_scope=class_scope, local_names=local_names
    )


def _named_expression_bindings(node: ast.AST) -> set[str]:
    names = {node.target.id} if isinstance(node, ast.NamedExpr) else set[str]()
    children: Iterable[ast.AST]
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        children = [*node.decorator_list, node.args]
        if node.returns is not None:
            children = [*children, node.returns]
    elif isinstance(node, ast.ClassDef):
        children = [*node.bases, *node.keywords, *node.decorator_list]
    elif isinstance(node, ast.Lambda):
        children = [node.args]
    elif isinstance(node, ast.GeneratorExp):
        children = [node.generators[0].iter]
    else:
        children = ast.iter_child_nodes(node)
    return names | {
        name for child in children for name in _named_expression_bindings(child)
    }


def _references(
    nodes: Iterable[ast.AST],
    *,
    class_scope: bool = False,
    local_names: frozenset[str] = frozenset(),
) -> set[str]:
    return {
        name
        for node in nodes
        for name in _evaluated_names(
            node, class_scope=class_scope, local_names=local_names
        )
    }


def _type_parameters(node: ast.AST) -> set[str]:
    parameters: set[str] = set()
    for field, value in ast.iter_fields(node):
        if field == "type_params" and isinstance(value, list):
            for parameter in ast.iter_child_nodes(node):
                name = getattr(parameter, "name", None)
                is_type_parameter = type(parameter).__name__ in {
                    "TypeVar",
                    "ParamSpec",
                    "TypeVarTuple",
                }
                if is_type_parameter and isinstance(name, str):
                    parameters.add(name)
    return parameters
